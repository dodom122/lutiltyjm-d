const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const noblox = require('noblox.js');
require('dotenv').config();

// Create a new client instance
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessages] });

// Define the slash commands
const commands = [
    new SlashCommandBuilder()
        .setName('promote')
        .setDescription('Promote a user to a specific role')
        .addUserOption(option => option.setName('user').setDescription('The user to promote').setRequired(true))
        .addStringOption(option => option.setName('role').setDescription('The role to assign').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('The reason for promotion').setRequired(true)),
    new SlashCommandBuilder()
        .setName('infract')
        .setDescription('Apply an infraction to a user')
        .addUserOption(option => option.setName('user').setDescription('The user to inflict').setRequired(true))
        .addStringOption(option => option.setName('reason').setDescription('The reason for infraction').setRequired(true))
        .addStringOption(option => option.setName('type').setDescription('The type of infraction')
            .addChoices(
                { name: 'Strike', value: 'strike' },
                { name: 'Demotion', value: 'demotion' },
                { name: 'Termination', value: 'termination' }
            ).setRequired(true))
        .addStringOption(option => option.setName('demote_role').setDescription('The role to demote to (required for demotion)').setRequired(false)),
    new SlashCommandBuilder()
        .setName('shift')
        .setDescription('Announce a shift being hosted'),
    new SlashCommandBuilder()
        .setName('dm')
        .setDescription('Send a direct message to a user')
        .addUserOption(option => option.setName('user').setDescription('The user to DM').setRequired(true))
        .addStringOption(option => option.setName('message').setDescription('The message to send').setRequired(true))
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

// Register the slash commands
(async () => {
    try {
        console.log('Started refreshing application (/) commands.');

        await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commands },
        );

        console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
        console.error(error);
    }
})();

// Login to Roblox
async function startApp() {
    try {
        await noblox.setCookie(process.env.ROBLOX_COOKIE);
        console.log('Logged into Roblox!');
    } catch (error) {
        console.error(`Failed to login: ${error.message}`);
    }
}

startApp();

// Event listener for when the bot is ready
client.once('ready', async () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

// Event listener for interactions
client.on('interactionCreate', async interaction => {
    if (interaction.isCommand()) {
        const { commandName, options } = interaction;

        if (commandName === 'promote') {
            await interaction.deferReply({ ephemeral: true });
            const user = options.getUser('user');
            const roleName = options.getString('role');
            const reason = options.getString('reason');
            const member = await interaction.guild.members.fetch(user.id);
            const role = interaction.guild.roles.cache.find(r => r.name === roleName);

            if (member && role) {
                await member.roles.add(role);

                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('RexoMart Staff Member Promotion')
                    .addFields(
                        { name: 'Username:', value: `${user}` },
                        { name: 'New Rank:', value: `${role}` },
                        { name: 'Reason:', value: reason },
                        { name: 'Promoted By:', value: `${interaction.user}` }
                    )
                    .setTimestamp()
                    .setFooter({ text: 'Automatically Ranked in server.' });

                const channel = interaction.guild.channels.cache.find(ch => ch.name === 'promotions');
                if (channel) {
                    await channel.send(`${user}`);
                    await channel.send({ embeds: [embed] });
                    await interaction.editReply({ content: 'Promotion processed and announcement sent!', ephemeral: true });
                } else {
                    await interaction.editReply('Promotions channel not found.');
                }
            } else {
                await interaction.editReply('Role or user not found.');
            }
        } else if (commandName === 'infract') {
            await interaction.deferReply({ ephemeral: true });
            const user = options.getUser('user');
            const reason = options.getString('reason');
            const type = options.getString('type');
            const demoteRoleName = options.getString('demote_role');
            const member = await interaction.guild.members.fetch(user.id);
            const channel = interaction.guild.channels.cache.find(ch => ch.name === 'infractions');

            if (!member) {
                return interaction.editReply('User not found.');
            }

            let actionMessage = '';
            let embedFields = [
                { name: 'Username:', value: `${user}` },
                { name: 'Reason:', value: reason },
                { name: 'Infraction Type:', value: type.charAt(0).toUpperCase() + type.slice(1) },
                { name: 'Issued By:', value: `${interaction.user}` }
            ];

            if (type === 'strike') {
                actionMessage = `${user} has received a strike.`;
            } else if (type === 'demotion') {
                const demoteRole = interaction.guild.roles.cache.find(r => r.name === demoteRoleName);

                if (!demoteRole) {
                    return interaction.editReply('Demotion role not found.');
                }

                await member.roles.set([demoteRole]);
                actionMessage = `${user} has been demoted to ${demoteRole}.`;
                embedFields.push({ name: 'New Rank:', value: `${demoteRole}` });
            } else if (type === 'termination') {
                const memberRole = interaction.guild.roles.cache.find(r => r.name === 'Member');
                if (!memberRole) {
                    return interaction.editReply('Member role not found.');
                }

                const rolesToRemove = member.roles.cache.filter(role => role.name !== 'Member');
                await member.roles.remove(rolesToRemove);
                await member.roles.add(memberRole);
                actionMessage = `${user} has been terminated and assigned the Member role.`;
                embedFields.push({ name: 'New Rank:', value: `${memberRole}` });
            }

            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('RexoMart Staff Member Infraction')
                .addFields(embedFields)
                .setTimestamp()
                .setFooter({ text: 'Action has been taken on the user.' });

            if (channel) {
                await channel.send(`${user}`);
                await channel.send({ embeds: [embed] });
                await interaction.editReply({ content: `Infraction processed and announcement sent! ${actionMessage}`, ephemeral: true });
            } else {
                await interaction.editReply('Infractions channel not found.');
            }
        } else if (commandName === 'shift') {
            await interaction.deferReply({ ephemeral: true });
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('Shift Announcement')
                .setDescription(`A Shift Is being hosted at our Store! Join using the link attached below!`)
                .addFields(
                    { name: 'Host:', value: `${interaction.user}` },
                    { name: 'Group link:', value: '[Join here!](https://www.roblox.com/communities/35100213/RexoMart-Corporation#!/about)' },
                    { name: 'Game link:', value: '[Join here!](https://www.roblox.com/games/76664997676454/RexoMart-Shopping)' },
                    { name: 'Any questions?', value: 'Open a support ticket!' }
                )
                .setTimestamp();

            const channel = interaction.guild.channels.cache.find(ch => ch.name === 'shifts');
            if (channel) {
                await channel.send({ embeds: [embed] });
                await interaction.editReply({ content: 'Shift announcement sent!', ephemeral: true });
            } else {
                await interaction.editReply('Shifts channel not found.');
            }
        } else if (commandName === 'dm') {
            await interaction.deferReply({ ephemeral: true });
            const user = options.getUser('user');
            const message = options.getString('message');

            try {
                await user.send(message);
                await interaction.editReply({ content: `Message sent to ${user.tag}`, ephemeral: true });
            } catch (error) {
                console.error(error);
                await interaction.editReply({ content: 'Failed to send the message. The user might have DMs disabled.', ephemeral: true });
            }
        }
    }
});

// Login to Discord with your client's token
client.login(process.env.TOKEN);
